import edu.princeton.cs.algs4.WeightedQuickUnionUF;
////import java.lang;

public class Percolation {
    private int[][] grid;
    private static int dim;
    private static int comp;
    private WeightedQuickUnionUF map;
    
    public Percolation(int n) {
        grid = new int[n][n];
        dim = n;
        map = new WeightedQuickUnionUF(n*n+2); 
        //added 2 is for the virtual nodes
    }
    
    private void checkParams(int i, int j) {
        if (i >= dim || i < 0 || j >= dim || j < 0) {
            throw new java.lang.IllegalArgumentException();
        }
    }
    
    private int hash(int x, int y) {
        return x*dim+y+1;
    }
    
    public boolean isOpen(int i, int j) {
        i = i-1;
        j = j-1;
        checkParams(i, j);
        return grid[i][j] == 1;    
    }
    
    public boolean isFull(int i, int j) {
        i = i-1;
        j = j-1;
        checkParams(i,j);
        return map.find(hash(i,j)) == map.find(0);
    }
    
    public boolean percolates(){
        return map.connected(0,dim*dim+1);
    }
    
    public int numberOfOpenSites(){
        int result = 0;
        for (int i = 0; i < dim; i++) {
            for (int j = 0; j < dim; i++) {
                result += grid[i][j];
            }
        }
        return result;
    }
    
    public void open(int i, int j) {
        if (!isOpen(i,j)) {
            i = i-1;
            j = j-1;
            checkParams(i,j);
            grid[i][j] = 1;
            int pt = hash(i,j);
            int[][] coords = {
                {0,1},
                {0,-1},
                {1,0},
                {-1,0}
            };
            for (int c = 0; c < coords.length; c++) {
                if (validConnection(i+coords[c][0],j+coords[c][1])) {
                    map.union(pt, hash(i+coords[c][0], j+coords[c][1]));
                }
            }
            if (i == 0) {
                map.union(pt, 0);
            } else if (i == dim-1) {
                map.union(pt, dim*dim+1);
            }
        }
    }
    
    private boolean validConnection(int x, int y) {
        if (x >= 0 && x < dim && y >= 0 && y < dim && grid[x][y] == 1) {
            return true;
        } 
        return false;
    }
    
    public static void main(String[] args) {
        Percolation perc = new Percolation(4);
        perc.open(1,1);
        System.out.println(perc.isOpen(1,1));
    }
}