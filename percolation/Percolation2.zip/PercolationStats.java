import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;
import java.lang.Math;


public class PercolationStats {

    private double[] trial_results;
    private double mean;
    private double stddev;
    
    public PercolationStats(int n, int trials){
        if (n <= 0 || trials <=0) {
            throw new java.lang.IllegalArgumentException();
        }
        
        int rx = 1;
        int ry = 1;
        Percolation perc;
        trial_results = new double[trials];
        
        for (int i = 0; i < trials; i++) {
            int count = 0;
            perc = new Percolation(n);
            do {
                do {
                    rx = StdRandom.uniform(n)+1;
                    ry = StdRandom.uniform(n)+1;
//                    System.out.printf("x: %d, y: %d \n", rx, ry);
//                    System.out.println("Grid: "+perc.grid[rx-1][ry-1]);
                } while(perc.isOpen(rx, ry));
                
//                System.out.printf("Found! x: %d, y: %d \n", rx, ry );                
                count++;
                perc.open(rx,ry);
            } while (!perc.percolates());
                
            trial_results[i] = (count*1.0 / (n*n*1.0));
//            System.out.println(trial_results[i]);
        }
        mean = StdStats.mean(trial_results);
        stddev = StdStats.stddev(trial_results);
    }
    
    public double mean() {
        return mean;
    } // sample mean of percolation threshold
    
    public double stddev() {
        return stddev;
    }// sample standard deviation of percolation threshold
    
    private double confidenceDifferential() {
        return 1.96*stddev / Math.sqrt(trial_results.length);
    }
    
    public double confidenceLo() {
        return mean - confidenceDifferential();
    }// low  endpoint of 95% confidence interval
    
    public double confidenceHi(){
        return mean + confidenceDifferential();
    }// high endpoint of 95% confidence interval

    public static void main(String[] args) {
        PercolationStats percStats = new PercolationStats(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
        System.out.printf("Mean = %f \n", percStats.mean());
        System.out.printf("StdDev = %f \n", percStats.stddev());
        System.out.printf("Confidence Interval = [%f,%f] \n", percStats.confidenceLo(), percStats.confidenceHi());
    }// test client (described below)

}