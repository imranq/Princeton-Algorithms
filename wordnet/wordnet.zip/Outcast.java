import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import java.util.*;
import java.lang.*;

public class Outcast {
    private WordNet W;
    private int[][] nounDistances;
    private Iterable<String> nouns;
    private int size;
    
    public Outcast(WordNet wordnet)         // constructor takes a WordNet object
    {
        W = wordnet;
        nouns = W.nouns();
        size = 0;
        for (String m : nouns)
            size++;
        nounDistances = new int[size][size];
    }
    
    public String outcast(String[] nouns)   // given an array of WordNet nouns, return an outcast
    {
        int minDistance = Integer.MAX_VALUE;
        String minNoun = "";
        int x = 0;
        int y = 0;
        for (String n : nouns) {
            //sum distances
            
            int tDistance = 0;
            for (String m : nouns) {
                if (nounDistances[x][y] == 0) {
                    if (y < x) {
                        nounDistances[y][x] = W.distance(n,m);
                    }    
                } 
                tDistance += nounDistances[x][y];
                y++;
            }
            
            if (minDistance > tDistance) {
                minDistance = tDistance;
                minNoun = n;
            }
            x++;
        }
        return minNoun;
    }
    
    public static void main(String[] args)  // see test client below
    {
        WordNet wordnet = new WordNet(args[0], args[1]);
        Outcast outcast = new Outcast(wordnet);
        for (int t = 2; t < args.length; t++) {
            In in = new In(args[t]);
            String[] nouns = in.readAllStrings();
            StdOut.println(args[t] + ": " + outcast.outcast(nouns));
        }
    }
}