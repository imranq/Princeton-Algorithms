import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.BreadthFirstDirectedPaths;
import java.util.*;
import java.lang.*;

public class SAP {
    // constructor takes a digraph (not necessarily a Directed Acyclic Graph)
    private Digraph G;
    private int ancestor;
    private int a;
    private int b;
    private Stack<Integer> aToAncestor;
    private Stack<Integer> bToAncestor;    
    
    
    public SAP(Digraph D) {
        G = D;
    }

    private boolean validIndex(int v) {
        if (v > -1 && v < G.V()) {
            return true;
        }
        return false;
    }

    private void processIfNotAlreadyProcessed(int v, int w) {
        if (!validIndex(v) || !validIndex(w))
            throw new IllegalArgumentException("Invalid index");
        if (a == v && b == w) return;
        sapBFS(v,w);
    }
    
    // length of shortest ancestral path between v and w; -1 if no such path
    public int length(int v, int w) {
        processIfNotAlreadyProcessed(v, w);
        return aToAncestor.size() + bToAncestor.size() - 1;
    }
    
    // a common ancestor of v and w that participates in a shortest ancestral path; -1 if no such path
    public int ancestor(int v, int w) {
        processIfNotAlreadyProcessed(v, w);
        return ancestor;
    }

    // length of shortest ancestral path between any vertex in v and any vertex in w; -1 if no such path
    public int length(Iterable<Integer> v, Iterable<Integer> w) {
        int minLength = Integer.MAX_VALUE;
        int minAncestor = -1;
        //create pairs
        LinkedList<Pair> pairs = new LinkedList<Pair>();
        
        for (int x : v) {
            for (int y : w) {
                Pair pair = new Pair(x,y);
                if (!pairs.contains(pair)) {
                    if (this.length(x, y) < minLength) {
                        minLength = this.length(x,y);
                        minAncestor = ancestor;
                    }
                }
            }
        }
        
        return minAncestor;
    }

    // a common ancestor that participates in shortest ancestral path; -1 if no such path
    public int ancestor(Iterable<Integer> v, Iterable<Integer> w) {
        int minLength = Integer.MAX_VALUE;
        int ancestor = -1;
        LinkedList<Pair> pairs = new LinkedList<Pair>();
        
        for (int x : v) {
            for (int y : w) {
                Pair pair = new Pair(x,y);
                if (!pairs.contains(pair)) {
                    if (this.length(x, y) < minLength) {
                        minLength = this.length(x,y);
                    }
                }
            }
        }
        return ancestor;
    }

    private void sapBFS(int v, int w) {
    //returns the path of edges from v -> x -> w, x being the common ancestor
        int length = 0;
        BreadthFirstDirectedPaths aTree = new BreadthFirstDirectedPaths(G, v);
        BreadthFirstDirectedPaths bTree = new BreadthFirstDirectedPaths(G, w);
        
        a = v;
        b = w;
        
        length = -1;
        ancestor = -1;
        //get a list of common ancestors
        for (int i=0; i<G.V(); i++) {
            if (aTree.hasPathTo(i) && bTree.hasPathTo(i)) {
                int tLength = aTree.distTo(i) + bTree.distTo(i);
                if (length == -1 || tLength < length) {
                    length = tLength;
                    ancestor = i;
                }
            }
        }
    }
        
        
    // do unit testing of this class
    public static void main(String[] args) {
        
        
    }
}



