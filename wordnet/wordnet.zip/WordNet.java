import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.StdIn;
import java.util.*;
import java.lang.*;
import java.io.File;

public class WordNet {
    // constructor takes the name of the two input files
    private Digraph wordgraph;
    private SAP wordsap;
    private Map<Integer, String> idToSynset;
    private Map<String, Integer> nounToId;
    
    
    /*
     * Why use Iterable?
     * How to calculate distance?
     * 
     */
    
    public WordNet(String synset_file, String hypernym_file) { //returns a file
        //process input files
        //Load the synset definitions?
        if (synset_file == null || hypernym_file == null) {
            throw new IllegalArgumentException("The synsets are null");
        }

        
        String[] synarr = new In(new File(synset_file)).readAll().split("\n");
        String[] hyperarr = new In(new File(hypernym_file)).readAll().split("\n");
        idToSynset = new HashMap<>();
        nounToId = new HashMap<>();

        wordgraph = new Digraph(synarr.length);
        for (String hyperset_data : hyperarr) {
            String[] hdata = hyperset_data.split(",");
//            System.out.println(hdata[1]);
            for (int i = 1; i < hdata.length; i++) {
//                System.out.println(hdata[0]);
                wordgraph.addEdge(Integer.parseInt(hdata[0]), Integer.parseInt(hdata[i]));
            }
        }
        
        CycleTester cycleTest = new CycleTester(wordgraph);
        if (!rootedDAG(wordgraph))
            throw new IllegalArgumentException("The graph has more than one root");
        if (cycleTest.hasCycle()) 
            throw new IllegalArgumentException("The graph has a cycle");
        
        for (String element : synarr) {
            String[] sdata = element.split(",");
            String nouns = sdata[1].trim();
            int id = Integer.parseInt(sdata[0]);
            String[] noun_arr = nouns.split(" ");
            idToSynset.put(id, nouns);
            for (String noun : noun_arr) {
                nounToId.put(noun, id);
            }
        }
        
        wordsap = new SAP(wordgraph);
    }
    
    private boolean rootedDAG(Digraph G) {
       int roots = 0;
       for (int i=0; i < G.V(); i++) {
           //check whether node has 
           if (!G.adj(i).iterator().hasNext()){
               roots++;
               if (roots > 1) {
                   return false;
               }
           }
       }
       if (roots == 1) {
           return true;
       } else {
           return false;
       }
    }
    
    // returns all WordNet nouns
    public Iterable<String> nouns() {
        return nounToId.keySet();
    }

    // is the word a WordNet noun?
    public boolean isNoun(String word) {
        if (word == null) {
            throw new IllegalArgumentException("Word is null");
        }
        
        //see whether wordnet includes a specific id
        for (String noun : nounToId.keySet()) {
            if (noun == word) {
                return true;
            }
        }
        return false;
    }

    // distance between nounA and nounB (defined below)
    public int distance(String nounA, String nounB) {
        if (nounA == null || nounB == null || !nounToId.containsKey(nounA) || !nounToId.containsKey(nounB)) {
            throw new IllegalArgumentException();
        }
        
        int idA = nounToId.get(nounA);
        int idB = nounToId.get(nounB);
        //how many edges exist between two ids
        int[] checkedIds = new int[1];
        return idDistance(idA,idB,checkedIds);
    }
    
    private int idDistance(int idA, int idB, int[] checkedIds) {
        for (int id : wordgraph.adj(idA)) {
            if (id == idB) {
                return 1;
            } 
        }
        
        for (int id : wordgraph.adj(idA)) {
            if (!inArray(checkedIds,id)){
                int[] cid = new int[checkedIds.length+1];
                for (int i = 0; i < checkedIds.length; i++) {
                    cid[i] = checkedIds[i];
                }
                cid[cid.length-1] = id; 
                return 1 + idDistance(id, idB, cid);
            }
        }
        return 0;
    }

    private boolean inArray(int[] arr, int needle) {
        for (int el : arr) {
            if (el == needle) {
                return true;
            }
        }
        return false;
    }
    
    // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
    // in a shortest ancestral path (defined below)
    public String sap(String nounA, String nounB) {
        if (nounA == null || nounB == null || !nounToId.containsKey(nounA) || !nounToId.containsKey(nounB)) {
            throw new IllegalArgumentException();
        }
        
        int idA = nounToId.get(nounA);
        int idB = nounToId.get(nounB);
        //find root between two nouns
        //go through each adjacency for each id until both paths get a match
        
        return idToSynset.get(wordsap.ancestor(idA, idB));
    }
    

    private int intersection(Iterable<Integer> a, Iterable<Integer> b) {
        for (int elA : a) {
            for (int elB : b) {
                if (elA == elB) {
                    return elA;
                }
            }
        }
        return -1;
    }


    // do unit testing of this class
    public static void main(String[] args) {
        String[] userInput = {"synsets6.txt", "hypernyms.txt"};//{"synsets.txt", "hypernyms.txt"};//reader.next().split(" ");
        
        WordNet wordnet = new WordNet("synsets6.txt", "hypernyms6TwoAncestors.txt");
        System.out.println(wordnet.sap("b","f"));

    }
}
